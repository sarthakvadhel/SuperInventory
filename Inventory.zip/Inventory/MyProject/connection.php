<?php
 include("tpl/db.class.php");
$db = new DB("posnic", "localhost", "root", "vertrigo");
?>