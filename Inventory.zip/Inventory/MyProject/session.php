<?php
session_start(); // Use session variable on this page. This function must put on the top of page.
if(!isset($_SESSION['username']) || $_SESSION['usertype'] !='admin'){ // if session variable "username" does not exist.
header("location:index.php?msg=Please%20login%20to%20access%20admin%20area%20!"); // Re-direct to index.php
}
	error_reporting (E_ALL ^ E_NOTICE);
	include("lib/db.class.php");
	include_once "config.php"; 
	error_reporting (E_ALL ^ E_NOTICE);

?>