<?php   $config["database"] = "posnic"; 
		$config["host"]= "localhost";
		$config["username"]= "root"; 
		$config["password"]= "";
		?>